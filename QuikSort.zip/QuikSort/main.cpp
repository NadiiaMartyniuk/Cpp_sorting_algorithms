#include <iostream>
#include<string>
#include<fstream>
#include <sstream>

using namespace std;

struct student {
    string imie;
    string nazwisko;
    int punkty=0;
};

void wczytajStudentow(student*&tab, int *n);
void wyswietlStudentow(student* tab, int i, int n);
void zadanie4_1(student*&tab, int *n);
void zadanie4_2(student*&tab, int *n);
int sortowanieQuickSort(student* tab, int n, int granica);
void usunTabliceStudentow(student *&tab);

void wczytajStudentow(student*&tab, int *n){
    string linia;
    int liczbaStudentow;
    ifstream plik;
    char sredniki;
    plik.open("studenci.csv");
    plik >> liczbaStudentow;
    tab = new student[liczbaStudentow];
    for(int i = 0; i < 2; i++)
        plik >> sredniki;
    for(int i=0; i<liczbaStudentow; i++){
        plik>>linia;
        istringstream ss(linia);
        getline(ss, tab[i].imie, ';');
        getline(ss, tab[i].nazwisko, ';');
        ss >> tab[i].punkty;
        }
    *n=liczbaStudentow;
    plik.close();

}
void wyswietlStudentow(student* tab, int i, int n){
    for (i; i<n; i++){
        cout<<i<<" "<<tab[i].imie<<" "<<tab[i].nazwisko<<", ocena: "<<tab[i].punkty<<endl;
        cout<<"n= "<<n;
    }
}

void zadanie4_1(student*&tab, int *n){
    delete []tab;
    wczytajStudentow(tab, n);

}
void zadanie4_2(student*&tab, int *n){
    int granica, meza, poczatok;
    cout<<"TABLICA STUDENTOW PRZED SORTOWANIEM: "<<endl;
    poczatok=0;
    wyswietlStudentow(tab, poczatok, *n);
    granica=10;
    meza=sortowanieQuickSort(tab, *n, granica);
    cout<<endl<<"Studenci, ktorzy otrzymali <=10: "<<endl;
    wyswietlStudentow(tab, poczatok, meza);
    cout<<endl<<"Studenci, ktorzy otrzymali >10: "<<endl;
    wyswietlStudentow(tab, meza, *n);
    cout<<"erdgdfgf";
}


int sortowanieQuickSort(student* tab, int n, int granica){
    int i, j;
    i=0;
    j=n-1;
    while(i<j){
        while ((tab[i].punkty<=granica) && (i<j))
            i+=1;
        while ((tab[j].punkty>granica) && (i<j))
            j-=1;
        if (i<j){
            swap(tab[i], tab[j]);
            i ++;
            j --;
        }
    }
    if (tab[i].punkty<=granica)
        return i+1;
    else
        return i;
}


void usunTabliceStudentow(student *&tab){
    delete []tab;
}

int main()
{
    student* tab = nullptr;
    int n;
    zadanie4_1(tab, &n);
    zadanie4_2(tab, &n);
    usunTabliceStudentow(tab);
    return 0;
}
